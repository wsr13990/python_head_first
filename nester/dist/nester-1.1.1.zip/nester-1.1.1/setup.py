from distutils.core import setup

setup(
    name        = 'nester',
    version     = '1.1.1',
    py_modules  = ['nester'],
    author      = 'WSR13990',
    author_email= 'wahyusejatiroso@yahoo.co.id',
    url         = 'http://www.example_rul.com',
    description = 'A simple printer of nested lists'
    )
